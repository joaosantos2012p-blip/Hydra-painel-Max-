# Hydra Painel (APK) — versão 2

App Android com bolha flutuante por cima de outros apps. O painel
(`app/src/main/assets/index.html`) roda numa WebView e funciona também
sozinho no navegador (com menos recursos).

## O que o painel tem

- **FPS:** número, gráfico, mínimo/média/máximo, pior 1%, quedas por minuto e estabilidade.
- **Sessões de jogo:** grava FPS, ping e temperatura por jogo, com histórico, estrela na melhor sessão e exportação em CSV.
- **Aparelho:** ping (variação e perda), conexão, temperatura, bateria, RAM e estado térmico, com aviso de calor.
- **Ferramentas:** cronômetro, timers (o alarme toca mesmo com o painel minimizado), bloco de notas e atalhos (links e apps favoritos).
- **Chat** com respostas rápidas editáveis (precisa de chave de API da Anthropic).
- **Vídeo:** link do YouTube ou .mp4 direto.
- **Ajustes:** o que a bolha mostra (FPS, ping, temperatura, bateria ou alternar), tamanho, opacidade, limite de calor e alvo do ping.

## Gerar o APK sem computador (GitHub)

1. Crie um repositório no GitHub e envie todos os arquivos desta pasta
   (inclusive a pasta oculta `.github`).
2. Abra a aba **Actions**, escolha **Build APK** e toque em **Run workflow**.
3. Em uns 3 a 5 minutos, baixe o **HydraPainel-APK** (vem num .zip com o `app-debug.apk`).
4. Instale no celular (libere "instalar apps desconhecidos" para o app que abrir o arquivo).

## Como usar

1. Abra o **Hydra Painel** e toque em **Ligar bolha**.
2. Libere **Sobrepor a outros apps** (e as notificações, se perguntar). Ao voltar ao app, a bolha liga sozinha.
3. A bolha aparece por cima de qualquer app. Arraste para mover; toque para abrir o painel.
4. No painel: segure o cabeçalho para arrastar e use **Minimizar** para voltar à bolha.
5. Para desligar: botão **Parar** na notificação, ou **Desligar bolha** no app.

Em Xiaomi, Samsung e Oppo pode ser preciso ativar também "Exibir pop-ups durante
execução em segundo plano" em Permissões do app.

## Limites conhecidos

- O número de FPS é o da **tela** (rótulo "TELA"), não o do jogo. O FPS real do jogo vem na etapa 3 (precisa do Shizuku).
- O uso de CPU não é liberado para apps comuns, por isso não aparece.
- O ping mede o tempo até um endereço (padrão 1.1.1.1), não até o servidor do jogo.
- Timers: se o celular entrar em suspensão profunda (tela apagada por muito tempo), o alarme pode atrasar.
- Vídeo do YouTube dentro do painel pode não carregar em alguns aparelhos; use "Abrir no navegador/YouTube".
