package com.hydra.painel

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Serviço que desenha a bolha flutuante (por cima de outros apps) e o painel
 * (uma WebView com o index.html) usando a permissão "Sobrepor a outros apps".
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.hydra.painel.STOP"
        private const val CHANNEL_ID = "hydra_overlay"
        private const val NOTIF_ID = 1
        private const val PREFS = "hydra"

        @Volatile
        var running = false
            private set

        /** Último erro ao ligar a bolha (a tela inicial mostra isso). */
        @Volatile
        var lastError: String? = null
    }

    private fun reportError(msg: String) {
        lastError = msg
        runCatching { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    // ---- bolha ----
    private var bubbleBox: LinearLayout? = null
    private var fpsNumber: TextView? = null
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var bubbleAttached = false

    // ---- painel ----
    private var panelFrame: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var webView: WebView? = null
    private var panelShown = false

    // ---- medidas, configuração e alarmes ----
    private lateinit var tele: Telemetry

    @Volatile
    private var cfg = JSONObject()
    private var labelView: TextView? = null
    private var bubbleBg: GradientDrawable? = null
    private val alarms = HashMap<String, Runnable>()
    private var alive = false
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!alive) return
            if (tele.onFrame(frameTimeNanos)) refreshBubble()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        // Precisa ser chamado logo, senão o Android derruba o app.
        lastError = null
        cfg = runCatching {
            JSONObject(getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("cfg", "{}") ?: "{}")
        }.getOrDefault(JSONObject())
        tele = Telemetry(this) { cfg.optString("pingHost", "1.1.1.1") }
        try {
            startAsForeground()
        } catch (e: Throwable) {
            reportError("Falha ao iniciar o serviço: ${e.javaClass.simpleName}: ${e.message}")
            stopSelf()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            reportError("Falta a permissão \"Sobrepor a outros apps\"")
            stopSelf()
            return
        }
        try {
            buildBubble()
        } catch (e: Throwable) {
            reportError("Falha ao criar a bolha: ${e.javaClass.simpleName}: ${e.message}")
            stopSelf()
            return
        }
        if (!attachBubble()) {
            stopSelf()
            return
        }
        running = true
        alive = true
        tele.start()
        Choreographer.getInstance().postFrameCallback(frameCb)
        Toast.makeText(applicationContext, "Bolha ligada", Toast.LENGTH_SHORT).show()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        alive = false
        running = false
        if (::tele.isInitialized) tele.stop()
        alarms.clear()
        main.removeCallbacksAndMessages(null)
        if (panelShown) {
            panelFrame?.let { runCatching { wm.removeView(it) } }
            panelShown = false
        }
        if (bubbleAttached) {
            bubbleBox?.let { runCatching { wm.removeView(it) } }
            bubbleAttached = false
        }
        webView?.apply {
            (parent as? FrameLayout)?.removeView(this)
            destroy()
        }
        webView = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        main.post {
            if (!alive) return@post
            val (w, h) = screen()
            bubbleLp.x = bubbleLp.x.coerceIn(0, max(0, w - bubbleLp.width))
            bubbleLp.y = bubbleLp.y.coerceIn(0, max(0, h - bubbleLp.height))
            updateBubble()
            val lp = panelLp
            val frame = panelFrame
            if (panelShown && lp != null && frame != null) {
                fitPanel(lp)
                runCatching { wm.updateViewLayout(frame, lp) }
            }
        }
    }

    // =====================================================================
    // Notificação (obrigatória para serviço em primeiro plano)
    // =====================================================================
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Hydra Painel", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Hydra Painel ativo")
            .setContentText("Toque na bolha para abrir o painel")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat), "Parar", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    // =====================================================================
    // Utilidades
    // =====================================================================
    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()

    private fun screen(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private val cOk = Color.parseColor("#34D399")
    private val cWarn = Color.parseColor("#FBBF24")
    private val cBad = Color.parseColor("#F87171")
    private val cMute = Color.parseColor("#8B95A8")
    private val cAccent = Color.parseColor("#22D3EE")

    private fun cfgInt(key: String, def: Int): Int = cfg.optInt(key, def)
    private fun cfgStr(key: String, def: String): String = cfg.optString(key, def)

    private fun fpsColor(fps: Int): Int = when {
        fps >= 50 -> cOk
        fps >= 30 -> cWarn
        else -> cBad
    }

    private fun pingColor(p: Int): Int = when {
        p < 0 -> cMute
        p < 60 -> cOk
        p < 120 -> cWarn
        else -> cBad
    }

    private fun tempColor(t: Float, warn: Int): Int = when {
        t.isNaN() -> cMute
        t < warn - 4 -> cOk
        t < warn -> cWarn
        else -> cBad
    }

    /** Atualiza o texto/cor da bolha conforme o modo escolhido nos Ajustes. */
    private fun refreshBubble() {
        var mode = cfgStr("bubble", "fps")
        if (mode == "mix") {
            val order = listOf("fps", "ping", "temp")
            mode = order[((System.currentTimeMillis() / 3000L) % 3L).toInt()]
        }
        val warn = cfgInt("tempWarn", 42)
        val t = tele.tempC
        val num: String
        val lab: String
        val col: Int
        when (mode) {
            "ping" -> {
                val p = tele.ping
                num = if (p >= 0) p.toString() else "--"
                lab = "PING"
                col = pingColor(p)
            }
            "temp" -> {
                num = if (t.isNaN()) "--" else "${t.roundToInt()}°"
                lab = "TEMP"
                col = tempColor(t, warn)
            }
            "bat" -> {
                val b = tele.battery
                num = if (b >= 0) "$b%" else "--"
                lab = "BAT"
                col = when {
                    b < 0 -> cMute
                    tele.charging || b > 30 -> cOk
                    b > 15 -> cWarn
                    else -> cBad
                }
            }
            else -> {
                num = tele.fps.toString()
                lab = "TELA"
                col = fpsColor(tele.fps)
            }
        }
        fpsNumber?.apply {
            text = num
            setTextColor(col)
        }
        labelView?.text = lab
        val hot = !t.isNaN() && t >= warn
        bubbleBg?.setStroke(dp(2), if (hot) cBad else cAccent)
    }

    /** Aplica tamanho e opacidade escolhidos nos Ajustes. */
    private fun applyBubbleStyle() {
        val sizeDp = cfgInt("size", 60).coerceIn(40, 100)
        val size = dp(sizeDp)
        bubbleLp.width = size
        bubbleLp.height = size
        bubbleBox?.alpha = cfgInt("opacity", 90).coerceIn(30, 100) / 100f
        fpsNumber?.textSize = 18f * sizeDp / 60f
        labelView?.textSize = 8f * sizeDp / 60f
        val (w, h) = screen()
        bubbleLp.x = bubbleLp.x.coerceIn(0, max(0, w - size))
        bubbleLp.y = bubbleLp.y.coerceIn(0, max(0, h - size))
        updateBubble()
        refreshBubble()
    }

    // =====================================================================
    // Bolha
    // =====================================================================
    private fun buildBubble() {
        val size = dp(cfgInt("size", 60).coerceIn(40, 100))

        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#E60B0E14"))
            setStroke(dp(2), Color.parseColor("#22D3EE"))
        }
        bubbleBg = bg
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg
        }
        val number = TextView(this).apply {
            text = "--"
            setTextColor(Color.parseColor("#34D399"))
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        val label = TextView(this).apply {
            text = "TELA"
            setTextColor(Color.parseColor("#8B95A8"))
            textSize = 8f
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        box.addView(number)
        box.addView(label)
        fpsNumber = number
        labelView = label
        bubbleBox = box

        val (_, h) = screen()
        bubbleLp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(4)
            y = min(dp(160), max(0, h - size))
        }

        box.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var downRawX = 0f
            private var downRawY = 0f
            private var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = bubbleLp.x
                        startY = bubbleLp.y
                        downRawX = e.rawX
                        downRawY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downRawX
                        val dy = e.rawY - downRawY
                        if (!moved && abs(dx) + abs(dy) > dp(8)) moved = true
                        if (moved) {
                            bubbleLp.x = (startX + dx).toInt()
                            bubbleLp.y = (startY + dy).toInt()
                            updateBubble()
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) snapBubble() else showPanel()
                    }
                    MotionEvent.ACTION_CANCEL -> if (moved) snapBubble()
                }
                return true
            }
        })
        applyBubbleStyle()
    }

    private fun attachBubble(): Boolean {
        val box = bubbleBox ?: return false
        if (bubbleAttached) return true
        return try {
            wm.addView(box, bubbleLp)
            bubbleAttached = true
            true
        } catch (e: Exception) {
            reportError("Não consegui mostrar a bolha: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    private fun detachBubble() {
        val box = bubbleBox ?: return
        if (!bubbleAttached) return
        runCatching { wm.removeView(box) }
        bubbleAttached = false
    }

    private fun updateBubble() {
        val box = bubbleBox ?: return
        if (!bubbleAttached) return
        runCatching { wm.updateViewLayout(box, bubbleLp) }
    }

    /** Ao soltar, a bolha gruda na borda esquerda ou direita. */
    private fun snapBubble() {
        val (w, h) = screen()
        val size = bubbleLp.width
        bubbleLp.y = bubbleLp.y.coerceIn(0, max(0, h - size))
        val target = if (bubbleLp.x + size / 2 < w / 2) dp(4) else w - size - dp(4)
        ValueAnimator.ofInt(bubbleLp.x, target).apply {
            duration = 180
            addUpdateListener {
                bubbleLp.x = it.animatedValue as Int
                updateBubble()
            }
            start()
        }
    }

    // =====================================================================
    // Painel (WebView)
    // =====================================================================
    private fun fitPanel(lp: WindowManager.LayoutParams) {
        val (w, h) = screen()
        lp.width = min((w * 0.96f).toInt(), dp(460))
        lp.height = (h * (if (h > w) 0.70f else 0.92f)).toInt()
        lp.x = lp.x.coerceIn(0, max(0, w - lp.width))
        lp.y = lp.y.coerceIn(0, max(0, h - lp.height))
    }

    private fun showPanel() {
        if (panelShown) return
        val frame = panelFrame ?: buildPanel().also { panelFrame = it }
        val lp = panelLp ?: WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // NOT_FOCUSABLE: o jogo continua com o foco (não pausa) enquanto você
            // só toca/assiste. A janela vira "focável" só na hora de digitar.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            val (w, h) = screen()
            width = min((w * 0.96f).toInt(), dp(460))
            height = (h * (if (h > w) 0.70f else 0.92f)).toInt()
            x = (w - width) / 2
            y = (h - height) / 2
        }.also { panelLp = it }

        fitPanel(lp)
        detachBubble()
        runCatching { wm.addView(frame, lp) }.onSuccess { panelShown = true }
            .onFailure { attachBubble() }
    }

    private fun hidePanel() {
        if (!panelShown) return
        hideKeyboard()
        panelLp?.let { it.flags = it.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE }
        panelFrame?.let { runCatching { wm.removeView(it) } }
        panelShown = false
        attachBubble()
    }

    private fun movePanelBy(dxPx: Int, dyPx: Int) {
        val lp = panelLp ?: return
        val frame = panelFrame ?: return
        if (!panelShown) return
        val (w, h) = screen()
        lp.x = (lp.x + dxPx).coerceIn(0, max(0, w - lp.width))
        lp.y = (lp.y + dyPx).coerceIn(0, max(0, h - lp.height))
        runCatching { wm.updateViewLayout(frame, lp) }
    }

    private fun setPanelFocusable(on: Boolean) {
        val lp = panelLp ?: return
        val frame = panelFrame ?: return
        if (!panelShown) return
        val currentlyFocusable = (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0
        if (on == currentlyFocusable) return
        lp.flags = if (on) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        runCatching { wm.updateViewLayout(frame, lp) }
        if (on) {
            main.postDelayed({
                val web = webView ?: return@postDelayed
                web.requestFocus()
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT)
            }, 120)
        } else {
            hideKeyboard()
        }
    }

    private fun hideKeyboard() {
        val web = webView ?: return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(web.windowToken, 0)
    }

    private fun buildPanel(): FrameLayout {
        val frame = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0B0E14"))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.parseColor("#232B3A"))
            }
            clipToOutline = true
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0B0E14"))
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            allowFileAccess = false
            allowContentAccess = false
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            // Nunca navega para fora do painel local.
            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean = request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")

        // Arrastar o painel segurando o cabeçalho (topo, fora do botão Minimizar).
        var dragging = false
        var lastX = 0f
        var lastY = 0f
        web.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = e.y < dp(48) && e.x < v.width - dp(110)
                    lastX = e.rawX
                    lastY = e.rawY
                    dragging
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) {
                        movePanelBy((e.rawX - lastX).toInt(), (e.rawY - lastY).toInt())
                        lastX = e.rawX
                        lastY = e.rawY
                        true
                    } else false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val was = dragging
                    dragging = false
                    was
                }
                else -> false
            }
        }

        web.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/index.html")
        frame.addView(
            web,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        webView = web
        return frame
    }

    /** Funções que o HTML chama via `Android.xxx(...)`. */
    inner class Bridge {
        @JavascriptInterface
        fun getKey(): String =
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("key", "") ?: ""

        @JavascriptInterface
        fun setKey(value: String) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("key", value).apply()
        }

        @JavascriptInterface
        fun minimize() {
            main.post { hidePanel() }
        }

        @JavascriptInterface
        fun setFocusable(on: Boolean) {
            main.post { setPanelFocusable(on) }
        }

        // ---- configuração (bolha, alertas, alvo do ping) ----
        @JavascriptInterface
        fun getConfig(): String = cfg.toString()

        @JavascriptInterface
        fun setConfig(json: String) {
            val novo = runCatching { JSONObject(json) }.getOrNull() ?: return
            val hostAntes = cfgStr("pingHost", "1.1.1.1")
            cfg = novo
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("cfg", json).apply()
            main.post {
                if (!alive) return@post
                if (cfgStr("pingHost", "1.1.1.1") != hostAntes) tele.resetPing()
                applyBubbleStyle()
            }
        }

        // ---- medidas e sessões ----
        @JavascriptInterface
        fun getStats(): String = if (::tele.isInitialized) tele.snapshot else "{}"

        @JavascriptInterface
        fun startSession(name: String) {
            tele.startSession(name)
        }

        @JavascriptInterface
        fun stopSession(): String = tele.stopSession()

        // ---- alarmes dos timers (tocam mesmo com o painel minimizado) ----
        @JavascriptInterface
        fun scheduleAlarm(id: String, ms: Double, label: String) {
            main.post { scheduleAlarmNow(id, ms.toLong(), label) }
        }

        @JavascriptInterface
        fun cancelAlarm(id: String) {
            main.post { cancelAlarmNow(id) }
        }

        // ---- atalhos ----
        @JavascriptInterface
        fun getApps(): String {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val list = pm.queryIntentActivities(intent, 0)
            val arr = JSONArray()
            list.map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .filter { it.second != packageName }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
                .forEach { arr.put(JSONObject().put("n", it.first).put("p", it.second)) }
            return arr.toString()
        }

        @JavascriptInterface
        fun launchApp(pkg: String) {
            main.post {
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i == null) {
                    reportError("App não encontrado")
                } else {
                    hidePanel()
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { startActivity(i) }
                        .onFailure { reportError("Não consegui abrir o app: ${it.message}") }
                }
            }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            main.post {
                val uri = runCatching { Uri.parse(url) }.getOrNull()
                if (uri == null || (uri.scheme != "http" && uri.scheme != "https")) {
                    reportError("Link inválido")
                } else {
                    hidePanel()
                    runCatching {
                        startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }.onFailure { reportError("Não consegui abrir o link: ${it.message}") }
                }
            }
        }
    }

    // =====================================================================
    // Alarmes
    // =====================================================================
    private fun scheduleAlarmNow(id: String, ms: Long, label: String) {
        cancelAlarmNow(id)
        val r = Runnable {
            alarms.remove(id)
            fireAlarm(label)
        }
        alarms[id] = r
        main.postDelayed(r, ms.coerceAtLeast(0L))
    }

    private fun cancelAlarmNow(id: String) {
        alarms.remove(id)?.let { main.removeCallbacks(it) }
    }

    @Suppress("DEPRECATION")
    private fun vibrator(): Vibrator =
        if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

    private fun fireAlarm(label: String) {
        Toast.makeText(applicationContext, "⏰ $label acabou!", Toast.LENGTH_LONG).show()
        runCatching {
            val tg = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1200)
            main.postDelayed({ tg.release() }, 1800L)
        }
        runCatching {
            vibrator().vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))
        }
    }
}
