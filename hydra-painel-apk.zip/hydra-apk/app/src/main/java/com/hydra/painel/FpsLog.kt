package com.hydra.painel

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Histórico diário do FPS da tela: por dia guarda quantos segundos foram medidos,
 * soma, mínimo, máximo e quantos segundos tiveram travadas.
 */
class FpsLog(private val prefs: SharedPreferences) {

    private val fmt = SimpleDateFormat("yyyyMMdd", Locale.US)
    private var day = ""
    private var n = 0L
    private var sum = 0L
    private var minV = Int.MAX_VALUE
    private var maxV = 0
    private var jankSec = 0L
    private var sinceFlush = 0

    @Synchronized
    fun add(fps: Int, jank: Int) {
        val d = fmt.format(Date())
        if (d != day) {
            flush()
            load(d)
        }
        n++
        sum += fps
        if (fps < minV) minV = fps
        if (fps > maxV) maxV = fps
        if (jank > 0) jankSec++
        sinceFlush++
        if (sinceFlush >= 30) flush()
    }

    private fun load(d: String) {
        day = d
        sinceFlush = 0
        val p = prefs.getString("log_$d", null)?.split(",")
        if (p != null && p.size == 5) {
            n = p[0].toLongOrNull() ?: 0L
            sum = p[1].toLongOrNull() ?: 0L
            minV = p[2].toIntOrNull() ?: Int.MAX_VALUE
            maxV = p[3].toIntOrNull() ?: 0
            jankSec = p[4].toLongOrNull() ?: 0L
        } else {
            n = 0L; sum = 0L; minV = Int.MAX_VALUE; maxV = 0; jankSec = 0L
        }
    }

    @Synchronized
    fun flush() {
        if (day.isEmpty() || n == 0L) return
        val mn = if (minV == Int.MAX_VALUE) 0 else minV
        prefs.edit().putString("log_$day", "$n,$sum,$mn,$maxV,$jankSec").apply()
        sinceFlush = 0
    }

    /** Últimos [days] dias (do mais novo para o mais antigo) que têm medições. */
    @Synchronized
    fun history(days: Int): JSONArray {
        flush()
        val arr = JSONArray()
        val cal = Calendar.getInstance()
        repeat(days) {
            val d = fmt.format(cal.time)
            val p = prefs.getString("log_$d", null)?.split(",")
            if (p != null && p.size == 5) {
                val nn = p[0].toLongOrNull() ?: 0L
                if (nn > 0) {
                    val js = p[4].toLongOrNull() ?: 0L
                    arr.put(
                        JSONObject()
                            .put("day", d)
                            .put("sec", nn)
                            .put("avg", ((p[1].toLongOrNull() ?: 0L) / nn).toInt())
                            .put("min", p[2].toIntOrNull() ?: 0)
                            .put("max", p[3].toIntOrNull() ?: 0)
                            .put("stable", (100 - js * 100 / nn).toInt())
                    )
                }
            }
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return arr
    }
}
