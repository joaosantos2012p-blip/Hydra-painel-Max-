package com.hydra.painel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Tela inicial: pede a permissão de sobreposição e liga/desliga a bolha. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private var pendingStart = false

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()

    private fun makeButton(label: String, filled: Boolean, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setTextColor(if (filled) Color.parseColor("#04121A") else Color.parseColor("#E6EAF2"))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                if (filled) {
                    setColor(Color.parseColor("#22D3EE"))
                } else {
                    setColor(Color.parseColor("#141923"))
                    setStroke(dp(1), Color.parseColor("#232B3A"))
                }
            }
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
            ).apply { topMargin = dp(12) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
            setBackgroundColor(Color.parseColor("#0B0E14"))
        }

        root.addView(TextView(this).apply {
            text = "🐉 Hydra Painel"
            textSize = 28f
            setTextColor(Color.parseColor("#22D3EE"))
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Bolha flutuante com medidor, chat e vídeo por cima dos seus jogos."
            textSize = 14f
            setTextColor(Color.parseColor("#8B95A8"))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(24))
        })

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#E6EAF2"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(status)

        root.addView(makeButton("Ligar bolha", true) { start() })
        root.addView(makeButton("Desligar bolha", false) {
            stopService(Intent(this, OverlayService::class.java))
            refresh()
        })
        root.addView(makeButton("Permissões do app (se a bolha não aparecer)", false) {
            // Em alguns celulares (Xiaomi, Samsung, Oppo...) há outra permissão
            // de "pop-up / janela em segundo plano" dentro de Permissões.
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        // Voltou da tela de permissão: liga a bolha sozinho.
        if (pendingStart && Settings.canDrawOverlays(this)) {
            pendingStart = false
            start()
        }
        refresh()
    }

    private fun refresh() {
        val err = OverlayService.lastError
        status.text = when {
            !Settings.canDrawOverlays(this) ->
                "Falta liberar \"Sobrepor a outros apps\".\nToque em Ligar bolha para abrir a configuração."
            OverlayService.running -> "Bolha ligada ✅"
            err != null -> "Erro: $err"
            else -> "Pronto para ligar."
        }
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            pendingStart = true
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            // O resultado chama launch() de qualquer jeito (negando, só some a notificação).
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        launch()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        launch()
    }

    private fun launch() {
        startForegroundService(Intent(this, OverlayService::class.java))
        // Espera um instante: se a bolha falhar, o erro aparece aqui na tela.
        status.text = "Ligando..."
        status.postDelayed({
            refresh()
            if (OverlayService.running) moveTaskToBack(true)
        }, 1200)
    }
}
