package com.hydra.painel

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Coleta as medidas que o painel mostra: FPS da tela, quedas, ping, bateria,
 * temperatura, RAM e estado térmico, e grava sessões de jogo.
 *
 * Quadros e aparelho: só a thread principal mexe (onFrame).
 * Ping: thread própria. O painel lê tudo pelo [snapshot] (texto JSON).
 */
class Telemetry(private val ctx: Context, private val pingHost: () -> String) {

    // ---- quadros (thread principal) ----
    private val dts = FloatArray(1800)
    private var dtCount = 0
    private var dtPos = 0
    private val stutterTimes = ArrayDeque<Long>()
    private var lastFrameNs = 0L
    private var frames = 0
    private var lastTickMs = 0L

    // ---- valores publicados ----
    @Volatile
    var fps = 0
        private set

    @Volatile
    var low1 = 0
        private set

    @Volatile
    var stutters = 0
        private set

    @Volatile
    var tempC = Float.NaN
        private set

    @Volatile
    var battery = -1
        private set

    @Volatile
    var charging = false
        private set

    @Volatile
    var ping = -1
        private set

    @Volatile
    var jitter = 0
        private set

    @Volatile
    var loss = 0
        private set

    @Volatile
    var snapshot = "{}"
        private set

    private var ramUsedMb = -1
    private var ramTotalMb = -1
    private var thermal = -1

    // ---- ping ----
    private val pingLock = Any()
    private val pingWin = ArrayList<Int>()

    @Volatile
    private var running = false
    private var pingThread: Thread? = null

    // ---- sessão ----
    private val sessLock = Any()
    private var sessActive = false
    private var sessName = ""
    private var sessStart = 0L
    private val sFps = ArrayList<Int>()
    private val sLow = ArrayList<Int>()
    private val sPing = ArrayList<Int>()
    private var sTempMax = Float.NaN
    private var sStut = 0

    // =====================================================================
    fun start() {
        if (running) return
        running = true
        pingThread = Thread {
            while (running) {
                val ms = measurePing()
                synchronized(pingLock) {
                    pingWin.add(ms)
                    if (pingWin.size > 10) pingWin.removeAt(0)
                    val ok = pingWin.filter { it >= 0 }
                    ping = if (ms >= 0) ms else (ok.lastOrNull() ?: -1)
                    loss = ((pingWin.size - ok.size) * 100f / pingWin.size).roundToInt()
                    var j = 0
                    for (i in 1 until ok.size) j += abs(ok[i] - ok[i - 1])
                    jitter = if (ok.size > 1) j / (ok.size - 1) else 0
                }
                try {
                    Thread.sleep(3000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.also {
            it.isDaemon = true
            it.start()
        }
    }

    fun stop() {
        running = false
        pingThread?.interrupt()
        pingThread = null
    }

    /** Chamar quando o alvo do ping mudar. */
    fun resetPing() {
        synchronized(pingLock) {
            pingWin.clear()
            ping = -1
            jitter = 0
            loss = 0
        }
    }

    private fun measurePing(): Int {
        val raw = pingHost().trim().ifEmpty { "1.1.1.1" }
        val host = raw.removePrefix("https://").removePrefix("http://")
            .substringBefore('/').substringBefore(':')
        return try {
            val addr = InetSocketAddress(host, 443)
            Socket().use { s ->
                val t0 = System.nanoTime()
                s.connect(addr, 2500)
                ((System.nanoTime() - t0) / 1_000_000L).toInt()
            }
        } catch (e: Exception) {
            -1
        }
    }

    // =====================================================================
    /** A cada quadro (thread principal). Retorna true quando fechou 1 segundo. */
    fun onFrame(frameTimeNanos: Long): Boolean {
        if (lastFrameNs != 0L) {
            val dtMs = (frameTimeNanos - lastFrameNs) / 1_000_000f
            if (dtMs < 2000f) {
                dts[dtPos] = dtMs
                dtPos = (dtPos + 1) % dts.size
                if (dtCount < dts.size) dtCount++
                if (dtMs > 50f) {
                    stutterTimes.addLast(System.currentTimeMillis())
                    synchronized(sessLock) { if (sessActive) sStut++ }
                }
            }
        }
        lastFrameNs = frameTimeNanos
        frames++

        val nowMs = frameTimeNanos / 1_000_000L
        if (lastTickMs == 0L) {
            lastTickMs = nowMs
            return false
        }
        val span = nowMs - lastTickMs
        if (span < 1000) return false

        secondTick((frames * 1000f / span).roundToInt())
        frames = 0
        lastTickMs = nowMs
        return true
    }

    private fun secondTick(f: Int) {
        fps = f
        var low = f
        if (dtCount >= 30) {
            val copy = dts.copyOf(dtCount)
            copy.sort()
            val p = copy[((dtCount - 1) * 0.99f).toInt()]
            if (p > 0f) low = min(f, (1000f / p).roundToInt())
        }
        low1 = low

        val cut = System.currentTimeMillis() - 60_000L
        while (stutterTimes.isNotEmpty() && stutterTimes.first() < cut) stutterTimes.removeFirst()
        stutters = stutterTimes.size

        readDevice()
        sessionSample()
        snapshot = buildSnapshot()
    }

    private fun readDevice() {
        try {
            val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
                tempC = if (t == Int.MIN_VALUE) Float.NaN else t / 10f
                val lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                battery = if (lv >= 0 && sc > 0) (lv * 100f / sc).roundToInt() else -1
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
                    st == BatteryManager.BATTERY_STATUS_FULL
            }
        } catch (e: Exception) {
            // mantém o último valor
        }
        try {
            val am = ctx.getSystemService(ActivityManager::class.java)
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            ramTotalMb = (mi.totalMem / 1048576L).toInt()
            ramUsedMb = ((mi.totalMem - mi.availMem) / 1048576L).toInt()
        } catch (e: Exception) {
        }
        thermal = try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.getSystemService(PowerManager::class.java).currentThermalStatus
            } else -1
        } catch (e: Exception) {
            -1
        }
    }

    private fun buildSnapshot(): String {
        val o = JSONObject()
        o.put("fps", fps)
        o.put("low1", low1)
        o.put("stutters", stutters)
        o.put("ping", ping)
        o.put("jitter", jitter)
        o.put("loss", loss)
        if (!tempC.isNaN()) o.put("tempC", Math.round(tempC * 10) / 10.0)
        if (battery >= 0) o.put("bat", battery)
        o.put("charging", charging)
        if (ramTotalMb > 0) {
            o.put("ramUsed", ramUsedMb)
            o.put("ramTotal", ramTotalMb)
        }
        o.put("thermal", thermal)
        return o.toString()
    }

    // =====================================================================
    // Sessões de jogo
    // =====================================================================
    fun startSession(name: String) {
        synchronized(sessLock) {
            sessActive = true
            sessName = name
            sessStart = System.currentTimeMillis()
            sFps.clear()
            sLow.clear()
            sPing.clear()
            sTempMax = Float.NaN
            sStut = 0
        }
    }

    private fun sessionSample() {
        synchronized(sessLock) {
            if (!sessActive) return
            sFps.add(fps)
            sLow.add(low1)
            if (ping >= 0) sPing.add(ping)
            val t = tempC
            if (!t.isNaN()) sTempMax = if (sTempMax.isNaN()) t else max(sTempMax, t)
        }
    }

    /** Encerra a sessão e devolve o resumo em JSON ("null" se não havia sessão). */
    fun stopSession(): String {
        return synchronized(sessLock) {
            if (!sessActive) return@synchronized "null"
            val o = JSONObject()
            o.put("name", sessName)
            o.put("start", sessStart)
            o.put("sec", ((System.currentTimeMillis() - sessStart) / 1000L).toInt())
            o.put("avg", if (sFps.isEmpty()) 0 else (sFps.sum() / sFps.size.toFloat()).roundToInt())
            o.put("min", sFps.minOrNull() ?: 0)
            o.put("max", sFps.maxOrNull() ?: 0)
            o.put("low1", sLow.minOrNull() ?: 0)
            o.put("pingAvg", if (sPing.isEmpty()) -1 else (sPing.sum() / sPing.size.toFloat()).roundToInt())
            if (!sTempMax.isNaN()) o.put("tempMax", Math.round(sTempMax * 10) / 10.0)
            o.put("stutters", sStut)
            sessActive = false
            o.toString()
        }
    }
}
