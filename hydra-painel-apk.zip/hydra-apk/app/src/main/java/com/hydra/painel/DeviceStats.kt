package com.hydra.painel

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import org.json.JSONObject
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/** Leituras do aparelho (bateria, temperatura, RAM, estado térmico) e ping. */
object DeviceStats {

    fun snapshot(ctx: Context): JSONObject {
        val o = JSONObject()

        // Bateria e temperatura da bateria (broadcast "grudado", não precisa de receiver)
        val b: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        var level = -1
        var temp = -1.0
        var charging = false
        if (b != null) {
            val l = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val s = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (l >= 0 && s > 0) level = l * 100 / s
            val raw = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            if (raw != Int.MIN_VALUE) temp = raw / 10.0
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
                st == BatteryManager.BATTERY_STATUS_FULL
        }
        o.put("battery", level)
        o.put("temp", temp)
        o.put("charging", charging)

        // RAM
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        o.put("ramTotalMb", mi.totalMem / 1048576L)
        o.put("ramFreeMb", mi.availMem / 1048576L)

        // Estado térmico do sistema (0 normal ... 6 desligando); -1 se o Android não informa
        var thermal = -1
        if (Build.VERSION.SDK_INT >= 29) {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            thermal = pm.currentThermalStatus
        }
        o.put("thermal", thermal)
        return o
    }

    /** Tempo (ms) para abrir uma conexão TCP na porta 443; -1 se falhar. */
    fun tcpPing(host: String, port: Int = 443, timeoutMs: Int = 2000): Int {
        return try {
            val addr = InetSocketAddress(InetAddress.getByName(host), port)
            val t0 = System.nanoTime()
            Socket().use { it.connect(addr, timeoutMs) }
            ((System.nanoTime() - t0) / 1_000_000L).toInt()
        } catch (e: Exception) {
            -1
        }
    }
}
